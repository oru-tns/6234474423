package com.example.youeat;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class EatActivity extends AppCompatActivity {

    private FoxView gameView ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eat);

        gameView = new FoxView(this) ;
        setContentView(gameView) ;
    }
}
