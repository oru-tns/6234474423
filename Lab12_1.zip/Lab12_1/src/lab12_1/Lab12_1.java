package lab12_1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Lab12_1 {

    public static void main(String[] args) throws FileNotFoundException {
        String message = "" ;
        Scanner in = new Scanner(System.in) ;
        boolean firstLine = true ;
        int lineCnt = 0 ;
        int wordCnt = 0 ;
        int charCnt = 0 ; 
        
        while (true)  {
            String line = in.nextLine() ;
            if (line.equals("quit"))  {
                break ;
            }
            else  {
                if (!firstLine)  {
                    message = message + "\n" + line ;
                }  else  {
                    message += line ;
                    firstLine = false ;
                }
            }
        }
        
        File file = new File("output.txt") ;
        PrintWriter output = new PrintWriter(file) ;
        output.print(message) ;
        output.close() ;
        Scanner read = new Scanner(file) ;
        
        while (read.hasNextLine()) {
            String line = read.nextLine() ;
            lineCnt++ ;
            String[] words = line.split(" ") ;
            wordCnt += words.length ;
            charCnt += line.length() ;
        }
        
        read.close() ;
        System.out.println("Total characters : " + charCnt) ;        
        System.out.println("Total words : " + wordCnt) ;        
        System.out.println("Total lines : " + lineCnt) ;        
    }        
}
