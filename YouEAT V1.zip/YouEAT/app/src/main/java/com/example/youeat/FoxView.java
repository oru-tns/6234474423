package com.example.youeat;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.view.View;

public class FoxView extends View {

    private Bitmap fox ;
    private Bitmap backgroundImage ;
    private Paint scorePaint = new Paint() ;

    public FoxView(Context context) {
        super(context);

        fox = BitmapFactory.decodeResource(getResources(), R.drawable.playfox) ;

        backgroundImage = BitmapFactory.decodeResource(getResources(), R.drawable.background02) ;

        scorePaint.setColor(Color.WHITE) ;
        scorePaint.setTextSize(70) ;
        scorePaint.setTypeface(Typeface.DEFAULT_BOLD) ;
        scorePaint.setAntiAlias(true) ;

    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        canvas.drawBitmap(backgroundImage,0,0,null) ;

        canvas.drawBitmap(fox, 0, 0, null) ;

        canvas.drawText("Score : ",20,60,scorePaint) ;
    }
}
