package lab12_2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Lab12_2 {

    public static void main(String[] args) {
        File file = new File("wordlist.txt") ;
        Scanner fileInput = null ;
        ArrayList<String> wordList = new ArrayList<>() ;
        
        try {
            fileInput = new Scanner(file) ;
            while (fileInput.hasNextLine()) {
                String line = fileInput.nextLine() ;
                wordList.add(line) ;
            }
        } 
        catch (FileNotFoundException e) {
            e.printStackTrace() ;
        } 
        finally {
            if (fileInput != null)  {
                fileInput.close() ;
            }
        }
        
        Scanner in = new Scanner(System.in) ;
        System.out.print("Enter a sentence: ") ;
        String message = in.nextLine() ;
        String wordsNotContained = "" ;
        boolean wordExist = true ;
        String[] words = message.split(" ") ;
        
        for (String word : words) {
            if (!wordList.contains(word)) {
                wordExist = false ;
                wordsNotContained = wordsNotContained + word + " " ;                
            }
        }
        System.out.println("Words not contained:") ;
        
        if (wordExist) {
            System.out.println("N/A") ;
        } else {
            System.out.println(wordsNotContained) ;
        }
    }    
}
